﻿
proyecto.readFile.Read();

//proyecto.readFile.Read();

Console.ReadLine(); 